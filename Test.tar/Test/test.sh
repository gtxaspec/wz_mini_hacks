#!/bin/sh

set -x
echo '\n------------welcome to wz_mini_hacks------------'

echo "enable leds"
echo 38 > /sys/class/gpio/export
echo 39 > /sys/class/gpio/export

echo out > /sys/class/gpio/gpio38/direction
echo out > /sys/class/gpio/gpio39/direction

echo "begin installation notify leds"
/tmp/Test/color.sh &

echo "mount mmc to /tmp/mmc"

mkdir /tmp/mmc
mount /dev/mmcblk0p1 /tmp/mmc

echo "create ssh host key dir"

mkdir /configs/.ssh

echo "disable auto load after install"
echo rename Test.tar to Test.tar.old
mv /tmp/mmc/Test.tar /tmp/mmc/Test.tar.old

echo "flash kernel to mtd1"
flashcp -v /tmp/mmc/kernel.bin /dev/mtd1

echo "flash apps to mtd3"
flashcp -v /tmp/mmc/appfs.bin /dev/mtd3

echo "flash modified rootfs to mtd2"
flashcp -v /tmp/mmc/rootfs2.bin /dev/mtd2

sync
sync

echo "installation done notify led"
pkill -f color.sh
echo 1 > "/sys/class/gpio/gpio39/value"
echo 1 > "/sys/class/gpio/gpio38/value"
echo 0 > "/sys/class/gpio/gpio39/value"

/tmp/Test/color_end.sh &
sleep 5
reboot
